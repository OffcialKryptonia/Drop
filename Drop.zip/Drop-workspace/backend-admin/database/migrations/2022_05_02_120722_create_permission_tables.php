<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\PermissionRegistrar;

use App\Helpers\SeederHelper;

class CreatePermissionTables extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $teams = config('permission.teams');
        $tableNames = config('permission.table_names');
        $columnNames = config('permission.column_names');
        $pivotRole = $columnNames['role_pivot_key'] ?? 'role_id';
        $pivotPermission = $columnNames['permission_pivot_key'] ?? 'permission_id';

        if (empty($tableNames)) {
            throw new \Exception('Error: config/permission.php not loaded. Run [php artisan config:clear] and try again.');
        }
        if ($teams && empty($columnNames['team_foreign_key'] ?? null)) {
            throw new \Exception('Error: team_foreign_key on config/permission.php not loaded. Run [php artisan config:clear] and try again.');
        }

        Schema::create($tableNames['permissions'], static function (Blueprint $table) {
            // $table->engine('InnoDB');
            $table->bigIncrements('id'); // permission id
            $table->string('name');       // For MyISAM use string('name', 225); // (or 166 for InnoDB with Redundant/Compact row format)
            $table->string('guard_name'); // For MyISAM use string('guard_name', 25);
            $table->unsignedBigInteger('parent_id')->nullable()->default(null);
            $table->timestamps();

            $table->unique(['name', 'guard_name']);
        });

        Schema::create($tableNames['roles'], static function (Blueprint $table) use ($teams, $columnNames) {
            // $table->engine('InnoDB');
            $table->bigIncrements('id'); // role id
            if ($teams || config('permission.testing')) { // permission.testing is a fix for sqlite testing
                $table->unsignedBigInteger($columnNames['team_foreign_key'])->nullable();
                $table->index($columnNames['team_foreign_key'], 'roles_team_foreign_key_index');
            }
            $table->string('name');       // For MyISAM use string('name', 225); // (or 166 for InnoDB with Redundant/Compact row format)
            $table->string('guard_name'); // For MyISAM use string('guard_name', 25);
            $table->tinyInteger('status')->nullable()->default('1');
            $table->timestamps();
            if ($teams || config('permission.testing')) {
                $table->unique([$columnNames['team_foreign_key'], 'name', 'guard_name']);
            } else {
                $table->unique(['name', 'guard_name']);
            }
        });

        Schema::create($tableNames['model_has_permissions'], static function (Blueprint $table) use ($tableNames, $columnNames, $pivotPermission, $teams) {
            $table->unsignedBigInteger($pivotPermission);

            $table->string('model_type');
            $table->unsignedBigInteger($columnNames['model_morph_key']);
            $table->index([$columnNames['model_morph_key'], 'model_type'], 'model_has_permissions_model_id_model_type_index');

            $table->foreign($pivotPermission)
                ->references('id') // permission id
                ->on($tableNames['permissions'])
                ->onDelete('cascade');
            if ($teams) {
                $table->unsignedBigInteger($columnNames['team_foreign_key']);
                $table->index($columnNames['team_foreign_key'], 'model_has_permissions_team_foreign_key_index');

                $table->primary([$columnNames['team_foreign_key'], $pivotPermission, $columnNames['model_morph_key'], 'model_type'],
                    'model_has_permissions_permission_model_type_primary');
            } else {
                $table->primary([$pivotPermission, $columnNames['model_morph_key'], 'model_type'],
                    'model_has_permissions_permission_model_type_primary');
            }

        });

        Schema::create($tableNames['model_has_roles'], static function (Blueprint $table) use ($tableNames, $columnNames, $pivotRole, $teams) {
            $table->unsignedBigInteger($pivotRole);

            $table->string('model_type');
            $table->unsignedBigInteger($columnNames['model_morph_key']);
            $table->index([$columnNames['model_morph_key'], 'model_type'], 'model_has_roles_model_id_model_type_index');

            $table->foreign($pivotRole)
                ->references('id') // role id
                ->on($tableNames['roles'])
                ->onDelete('cascade');
            if ($teams) {
                $table->unsignedBigInteger($columnNames['team_foreign_key']);
                $table->index($columnNames['team_foreign_key'], 'model_has_roles_team_foreign_key_index');

                $table->primary([$columnNames['team_foreign_key'], $pivotRole, $columnNames['model_morph_key'], 'model_type'],
                    'model_has_roles_role_model_type_primary');
            } else {
                $table->primary([$pivotRole, $columnNames['model_morph_key'], 'model_type'],
                    'model_has_roles_role_model_type_primary');
            }
        });

        Schema::create($tableNames['role_has_permissions'], static function (Blueprint $table) use ($tableNames, $pivotRole, $pivotPermission) {
            $table->unsignedBigInteger($pivotPermission);
            $table->unsignedBigInteger($pivotRole);

            $table->foreign($pivotPermission)
                ->references('id') // permission id
                ->on($tableNames['permissions'])
                ->onDelete('cascade');

            $table->foreign($pivotRole)
                ->references('id') // role id
                ->on($tableNames['roles'])
                ->onDelete('cascade');

            $table->primary([$pivotPermission, $pivotRole], 'role_has_permissions_permission_id_role_id_primary');
        });

       
        $permissions = [
                    [
                        'name' => 'role',
                        'sub_permission' => [ 'role add', 'role list', ],
                    ],
                    [
                        'name' => 'permission',
                        'sub_permission' => [
                            'permission add',
                            'permission list',
                        ],
                    ],
                    [
                        'name' => 'region',
                        'sub_permission' => [
                            'region list',
                            'region add',
                            'region edit',
                            'region delete',
                        ],
                    ],
                    [
                        'name' => 'service',
                        'sub_permission' => [
                            'service list',
                            'service add',
                            'service edit',
                            'service delete',
                        ],
                    ],
                    [
                        'name' => 'driver',
                        'sub_permission' => [
                            'driver list',
                            'driver add',
                            'driver edit',
                            'driver delete',
                            'pending driver',
                            'driver show',
                            'driverearning list',
                            'driver location',
                            'service-wise-report',
                        ],
                    ],
                    [
                        'name' => 'rider',
                        'sub_permission' => [
                            'rider list',
                            'rider add',
                            'rider edit',
                            'rider delete',
                            'rider show',
                        ],
                    ],
                    [
                        'name' => 'riderequest',
                        'sub_permission' => [
                            'riderequest list',
                            'riderequest show',
                            'riderequest delete',
                            'dispatch add',
                        ],
                    ],
                    [
                        'name' => 'document',
                        'sub_permission' => [
                            'document list',
                            'document add',
                            'document edit',
                            'document delete',
                        ],
                    ],
                    [
                        'name' => 'driverdocument',
                        'sub_permission' => [
                            'driverdocument list',
                            'driverdocument add',
                            'driverdocument edit',
                            'driverdocument delete',
                        ],
                    ],
                    [
                        'name' => 'coupon',
                        'sub_permission' => [
                            'coupon list',
                            'coupon add',
                            'coupon edit',
                            'coupon delete',
                        ],
                    ],
                    [
                        'name' => 'additionalfees',
                        'sub_permission' => [
                            'additionalfees list',
                            'additionalfees add',
                            'additionalfees edit',
                            'additionalfees delete',
                        ],
                    ],
                    [
                        'name' => 'sos',
                        'sub_permission' => [
                            'sos list',
                            'sos add',
                            'sos edit',
                            'sos delete',
                        ],
                    ],
                    [
                        'name' => 'complaint',
                        'sub_permission' => [
                            'complaint list',
                            'complaint add',
                            'complaint edit',
                            'complaint delete',
                            'complaint show',
                        ],
                    ],
                    [
                        'name' => 'pages',
                        'sub_permission' => [
                            'terms condition',
                            'privacy policy',
                            'pages list',
                            'pages add',
                            'pages edit',
                            'pages delete',
                        ],
                    ],
                    [
                        'name' => 'pushnotification',
                        'sub_permission' => [
                            'pushnotification list',
                            'pushnotification add',
                            'pushnotification delete',
                        ],
                    ],
        ];

        SeederHelper::seedPermissions($permissions);

        $sub_permission = array_merge(
            array_column($permissions, 'name'),
            ...array_column($permissions, 'sub_permission')
        );

        $new_permission = [];

        $roles = [
            [
                'name' => 'admin',
                'permissions' => array_merge(  $sub_permission, $new_permission  )
            ],
            [
                'name' => 'rider',
                'permissions' => [],
            ],
            [
                'name' => 'driver',
                'permissions' => [],
            ],
        ];

        SeederHelper::seedRoles($roles);

        app('cache')
            ->store(config('permission.cache.store') != 'default' ? config('permission.cache.store') : null)
            ->forget(config('permission.cache.key'));
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $tableNames = config('permission.table_names');

        if (empty($tableNames)) {
            throw new \Exception('Error: config/permission.php not found and defaults could not be merged. Please publish the package configuration before proceeding, or drop the tables manually.');
        }

        Schema::drop($tableNames['role_has_permissions']);
        Schema::drop($tableNames['model_has_roles']);
        Schema::drop($tableNames['model_has_permissions']);
        Schema::drop($tableNames['roles']);
        Schema::drop($tableNames['permissions']);
    }
}
